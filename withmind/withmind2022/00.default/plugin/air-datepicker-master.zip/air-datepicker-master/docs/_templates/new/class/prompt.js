module.exports = module.exports = require('../../shared/componentPrompt');
