import PageTitle from './pageTitle';
export default PageTitle;

