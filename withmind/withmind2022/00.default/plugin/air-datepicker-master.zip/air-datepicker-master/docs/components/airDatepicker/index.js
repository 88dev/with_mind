import AirDatepicker, {version} from './airDatepicker';
export {version};
export default AirDatepicker;
