
module.exports = function makeESIndex (){

};
